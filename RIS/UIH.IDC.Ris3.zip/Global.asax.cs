﻿using System;
using System.Collections.Specialized;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Threading;
using System.Web.Http;
using System.Web.Mvc;
using System.Web.Optimization;
using System.Web.Routing;
using Castle.Windsor;
using Microsoft.Practices.ServiceLocation;
using SolrNet;
using SolrNet.Mapping;
using SolrNet.Utils;
using UIH.IDC.Ris.App_Start;
using UIH.IDC.Ris.Areas.Lock.Service;
using UIH.IDC.Ris.Areas.StudyBusiness.Models;
using UIH.IDC.Ris.Common.Models;
using UIH.IDC.Ris.Common.Solr.Service;
using UIH.IDC.Ris.Common.Utils;
using UIH.IDC.Ris.Cst;
using UIH.Mcsf.Common.Controller;
using UIH.Mcsf.Common.Cst;
using UIH.Mcsf.Common.License;
using UIH.Mcsf.Common.Scheduler.Cst;
using UIH.Mcsf.Common.Scheduler.Service;
using UIH.Mcsf.Common.Utils;
using UIH.Mcsf.Component.Messager;
using UIH.IDC.Ris.Areas.BaseData.Service.BusinessManage;
using UIH.Plugs.License.Tools;
using ConfigHelper = UIH.Mcsf.Common.Utils.ConfigHelper;
using SolrNetStatup = SolrNet.Startup;
using log4net;

namespace UIH.IDC.Ris
{
    // Note: For instructions on enabling IIS6 or IIS7 classic mode, 
    // visit http://go.microsoft.com/?LinkId=9394801

    public class MvcApplication : System.Web.HttpApplication, IContainerAccessor
    {
        private static IWindsorContainer _container;

        protected ILog Logger
        {
            get { return LogManager.GetLogger(GetType()); }
        }
        protected void Application_Start()
        {
            Logger.Info("IIS启动");
            //if (!LicenseManager.Instance.InitAndValidate(LicenseCst.HswDpRis))
            //{
            //    throw new Exception("License验证无效，请联系系统管理员！");
            //}
            //初始化容器并注入相关实例到容器中
            ControllerFactory controllerFactory = null;
            string diCfgFile = ConfigHelper.GetNameValue(CommonCst.AppSettingsSection, "diCfgFile");
            if (string.IsNullOrWhiteSpace(diCfgFile))
                controllerFactory = new ControllerFactory();
            else
                controllerFactory = new ControllerFactory(diCfgFile);
            //缓存所有Action中不需要经过权限拦截的方法
            ControllerBuilder.Current.SetControllerFactory(controllerFactory.GetType());
            _container = CastleContainerHelper.GetContainer();

        
            //CacheHelper.CacheObject(CommonCst.IsAuditLogEnable, "true");
            AreaRegistration.RegisterAllAreas();
            WebApiConfig.Register(GlobalConfiguration.Configuration);

            RouteConfig.RegisterRoutes(RouteTable.Routes);
            BundleConfig.RegisterBundles(BundleTable.Bundles);
            AuthConfig.RegisterAuth();


            //var directorySeparator = Path.DirectorySeparatorChar.ToString(CultureInfo.CurrentCulture);

            //下面三行来源于/App_Code/InitApp.cs文件中的第17-19行，
            //用于解压dll后立即做部分处理：缓存所有Action中不需要经过权限拦截的方法
            //解决偶现DIM：511928
            var pluginPath = AppDomain.CurrentDomain.BaseDirectory + "PluginConfig.xml";
            PluginHelper.CacheAssemblyAnonymousAction(pluginPath);
            PluginHelper.CacheExcludeAuditLogAction(pluginPath);


            //读取解压后的文件到Cache中，满足国际化需要
            LangHelper.ReadPropertiesToCache(AppDomain.CurrentDomain.BaseDirectory + "Resources");

            var path = RisCst.SystemCfgDir + RisCst.SystemCfgFile;
            SystemEnvInfo.Register(AppDomain.CurrentDomain.BaseDirectory + path);

            SystemEnv systemEnv = SystemEnvInfo.GetSystemEnv();
            CacheHelper.CacheObject(CommonCst.IsAuditLogEnable, systemEnv.AuditLogEnable);

            FilterConfig.RegisterGlobalFilters(GlobalFilters.Filters);

            //如果启用solr,且配置了solr的url地址,则初始化solr
           
            if (systemEnv.UseSolrUrl)
            {
                if (!string.IsNullOrWhiteSpace(systemEnv.SolrUrl))
                {
                    SolrNetStatup.Init<Report>(systemEnv.SolrUrl);
                   var mapper = new PropertiesMappingManager();
                   // var mapper = new AllPropertiesMappingManager();
                   var container = new Container(SolrNetStatup.Container);
                   container.RemoveAll<IReadOnlyMappingManager>();
                   container.Register<IReadOnlyMappingManager>(c => mapper);
                   ServiceLocator.SetLocatorProvider(() => container);
                }
            }

            //向LIcense服务器发送版本信息
            var systeminfo = SystemEnvInfo.GetSystemEnv();
            var isUseLicense = systeminfo.UseLicense;
            LicenseResult lr = new LicenseResult();
            if ("true".Equals(isUseLicense))
            {
                var ip = systeminfo.LicenseIp;
                var port = systeminfo.LicensePort;
                string currentPath = AppDomain.CurrentDomain.BaseDirectory;
                currentPath = currentPath.Substring(0, currentPath.Length -1);
                int len = currentPath.LastIndexOf('\\');
                currentPath = currentPath.Substring(0, len);
                if (File.Exists(currentPath + "\\CurrentVersion.txt"))
                {
                    VersionHelper.sendVersion(ip, port, "RIS", currentPath + "\\CurrentVersion.txt");
                }              
            }

            //定时任务组件启动
            string ScheduleJobConfigPath = "Config" + Path.DirectorySeparatorChar.ToString(CultureInfo.InvariantCulture) + "ScheduleJob" + Path.DirectorySeparatorChar.ToString(CultureInfo.InvariantCulture);
            var jobConfigFile = AppDomain.CurrentDomain.BaseDirectory + ScheduleJobConfigPath + SchedulerCst.ScheduleJobConfigFile;
            var jobManageService = _container.Resolve<IJobManageService>();
            jobManageService.Startup(jobConfigFile);
            _container.Resolve<ISystemConfigService>().InitAllSystemConfig();
            _container.Resolve<IReportConfigService>().InitAllReportConfig();
            _container.Resolve<ISwitchConfigService>().InitAllSwitchConfig();
        }

        protected void Application_End()
        {
            Logger.Info("IIS关闭或回收。");
        }

        public IWindsorContainer Container
        {
            get { return _container; }
        }

        protected void Session_Start(object sender, EventArgs e)
        {

        }

        protected void Session_End(object sender, EventArgs e)
        {
            var sessionUserId = Session[RisCst.CurrentLoginUserRefid];
            string userId = sessionUserId == null ? "" : sessionUserId.ToString();
            MessageHelper.Send(userId, 6666, "SessionTime"); //后台推送消
            CastleContainerHelper.GetContainer().Resolve<IEntityLockService>().ClearLockBySession(Session.SessionID);
            ScreenHelper.RemoveScreenInfo(Session.SessionID);
        }
    }
}

﻿using Microsoft.Owin;
using Owin;
using UIH.IDC.Ris;
[assembly: OwinStartup(typeof(Startup))]
namespace UIH.IDC.Ris
{
    public class Startup
    {
        public void Configuration(IAppBuilder app)
        {
            app.MapSignalR();
        }
    }
}